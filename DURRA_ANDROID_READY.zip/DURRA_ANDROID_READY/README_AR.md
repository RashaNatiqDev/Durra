# DURRA — نسخة Android الجاهزة للبناء

هذه النسخة مأخوذة من DURRA_FINAL وتحافظ على HTML/CSS/JavaScript والبيانات المحلية.
تم تغليفها داخل تطبيق Android مستقل باستخدام WebView محلي، لذلك لا تحتاج إلى فتح Chrome لتشغيل DURRA.

## ما تم تجهيزه
- اسم التطبيق: DURRA
- معرف الحزمة: com.durra.planner
- اتجاه التطبيق: عمودي
- الحد الأدنى: Android 10 (API 29)
- الأيقونة: أيقونة DURRA الأصلية
- حفظ البيانات: localStorage داخل التطبيق
- استعادة النسخة الاحتياطية: اختيار ملف JSON من الهاتف
- إنشاء النسخة الاحتياطية: تحفظ داخل Downloads/DURRA

## الطريقة الأسهل للحصول على APK عبر GitHub
1. أنشئي Repository جديدًا في GitHub باسم DURRA-Android.
2. ارفعي محتويات هذا المجلد كاملة إلى جذر المستودع.
3. افتحي تبويب Actions.
4. افتحي Build DURRA APK.
5. اختاري Run workflow إذا لم يبدأ تلقائيًا.
6. بعد نجاح البناء، افتحي نتيجة التشغيل وانزلي إلى Artifacts.
7. نزّلي DURRA-APK؛ بداخله ملف app-debug.apk.

## البناء عبر Android Studio
1. افتحي Android Studio.
2. اختاري Open واختاري مجلد DURRA_ANDROID_READY.
3. انتظري مزامنة Gradle وتنزيل Android SDK إن طلبه البرنامج.
4. من Build اختاري Build APK(s).
5. ستجدين الملف في:
   app/build/outputs/apk/debug/app-debug.apk

ملاحظة: نسخة debug مناسبة للتثبيت الشخصي والتجربة. للنشر في Google Play يلزم إنشاء Release موقّع بمفتاح توقيع خاص.
