# DURRA does not currently require custom ProGuard rules.
